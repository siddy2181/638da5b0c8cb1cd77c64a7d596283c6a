import React, {Component} from 'react'
import {Table,Button} from 'react-bootstrap'
import WorkOrder from './WorkOrder'
import makeRequest from "./api/makeRequest"


class WorkOrderList extends Component {
    constructor(){
        super();
        this.state = {
            WorkOrders : []
        }
    }
    componentWillMount(){
        let self = this;
        makeRequest("http://104.211.31.153/ids", "GET")
            .then(function (result) {
                self.setState({WorkOrders : result})
            })
            .catch(function (err) {
                console.log(err)
            });
    }

    // DELETE Logic
    deleteWorkOrder(id){
        // console.log(id)
        let self = this;
        makeRequest("http://104.211.31.153/ids/" + id, 'DELETE')
            .then(function (result) {
                self.setState({WorkOrders : result})
            })
            .catch(function (err) {
                console.log(err)
            });
    }



    dequeueFirstOrder(){
        let self = this;
        makeRequest("http://104.211.31.153/dequeue", 'GET')
            .then(function (result) {
                self.setState({WorkOrders : result})
            })
            .catch(function (err) {
                console.log(err)
            });

    }
//http://104.211.31.153/ids

   /*shouldComponentUpdate(nextProps, nextState){
        console.log(nextState)
        return this.state.WorkOrders === nextState.WorkOrders;


    }*/

    render() {
        let WorkOrders = this.state.WorkOrders;
        return (
            <div>
                <Button>
                </Button>
                <Table striped bordered condensed hover>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Time of Creation</th>
                            <th>Work Order Type</th>
                            <th>Done</th>
                        </tr>
                    </thead>
                    <WorkOrder
                        orders = {WorkOrders}
                        deleteWorkOrder={this.deleteWorkOrder}
                    />
                </Table>
            </div>
        )
    }
}

export default WorkOrderList;
