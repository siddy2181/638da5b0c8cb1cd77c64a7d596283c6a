import React from 'react'
import WorkOrderList from './WorkOrderList'

const ServiceWork = () => (
  <div>
    <h1>Service Work Page</h1>
    <WorkOrderList/>
  </div>
)

export default ServiceWork
